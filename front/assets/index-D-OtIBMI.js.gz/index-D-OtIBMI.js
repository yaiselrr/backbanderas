import{D as n,_ as o}from"./dropdown-DdxiuV_U.js";n.Button=o,n.install=function(t){return t.component(n.name,n),t.component(o.name,o),t};
