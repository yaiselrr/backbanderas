import{r,w as a}from"./index-D0wN_fuZ.js";function e(e,n,o){const s=r(e());return a(n,((r,a)=>{o?o(r,a)&&(s.value=e()):s.value=e()})),s}export{e as u};
